import 'package:assignment/homeConstants.dart';
import 'package:flutter/material.dart';

import 'addressFromcoordinates.dart';
import 'currentLocation.dart';
import 'googleMaps.dart';
class mapHome extends StatefulWidget {
  const mapHome({Key? key}) : super(key: key);

  @override
  State<mapHome> createState() => _mapHomeState();
}

class _mapHomeState extends State<mapHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>HomePage()));
          }, child: Text("Get Current location")),
          SizedBox(height: 10),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>Convert_Lat_Long()));
          }, child: Text("Get address from coordinates")),
          SizedBox(height: 10),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>mapIntegration()));
          }, child: Text("Simple Map"))
        ],
      ),
    );
  }
}
