import 'package:assignment/homeConstants.dart';
import 'package:flutter/material.dart';

import 'Module2Part2/module2Part2Home.dart';
import 'Module3Part2/module3Part2home.dart';
import 'module2/module2Home.dart';
import 'module3/module3Home.dart';
class mainHome extends StatefulWidget {
  const mainHome({Key? key}) : super(key: key);

  @override
  State<mainHome> createState() => _mainHomeState();
}

class _mainHomeState extends State<mainHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Assignment"),
      ),
      body: Column(
        children:  [
          SizedBox(height: 260),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>module2HomePage()));
          },
              child: Text("Module 2")),
          SizedBox(height: 20),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>module3HomePage()));
          },
              child: Text("Module 3")),
          SizedBox(height: 20),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>module2part2Home()));
          },
              child: Text("Module 2 Part 2")),
          SizedBox(height: 20),
          GradientButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>Module3Part2Home()));
          },
              child: Text("Module 3 Part 2")),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
