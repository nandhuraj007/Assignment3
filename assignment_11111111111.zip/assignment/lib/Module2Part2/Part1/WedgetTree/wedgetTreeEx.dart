import 'package:flutter/material.dart';
class wedgettree extends StatefulWidget {
  const wedgettree({Key? key}) : super(key: key);

  @override
  State<wedgettree> createState() => _wedgettreeState();
}

class _wedgettreeState extends State<wedgettree> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          Column(
            children: [
              Icon(Icons.accessibility_new_sharp),
              Container(
                color: Colors.teal,
                child: Text("this is a text inside a container"),
              )
            ],
          ),
          Column(
            children: [
              Icon(Icons.account_circle_rounded),
              Container(
                color: Colors.teal,
                child: Text("this is a text inside a container"),
              )
            ],
          ),
          Column(
            children: [
              Icon(Icons.abc_outlined),
              Container(
                color: Colors.teal,
                child: Text("this is a text inside a container"),
              )
            ],
          )
        ],
      ),
    );

  }
}
