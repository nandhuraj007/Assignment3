import 'package:flutter/material.dart';

import '../homeConstants.dart';
class module2part2Home extends StatefulWidget {
  const module2part2Home({Key? key}) : super(key: key);

  @override
  State<module2part2Home> createState() => _module2part2HomeState();
}
class _module2part2HomeState extends State<module2part2Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>calculatorHomePage()));
              },
              child: Text("Part 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>MyHomePage()));
              },
              child: Text("Part 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>quizHomes()));
              },
              child: Text("Part 3")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>crudHome()));
              },
              child: Text("Part 4")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>TodoApp()));
              },
              child: Text("Part 5")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
