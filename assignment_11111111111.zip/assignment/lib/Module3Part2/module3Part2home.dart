import 'package:flutter/material.dart';

import '../homeConstants.dart';
class Module3Part2Home extends StatefulWidget {
  const Module3Part2Home({Key? key}) : super(key: key);

  @override
  State<Module3Part2Home> createState() => _Module3Part2HomeState();
}

class _Module3Part2HomeState extends State<Module3Part2Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>calculatorHomePage()));
              },
              child: Text("Part 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>MyHomePage()));
              },
              child: Text("Part 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>quizHomes()));
              },
              child: Text("Part 3")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>crudHome()));
              },
              child: Text("Part 4")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                //Navigator.push(context, MaterialPageRoute(builder: (context)=>TodoApp()));
              },
              child: Text("Part 5")),
        ],
      ),
    );
  }
}
